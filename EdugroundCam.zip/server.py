from flask import Flask, request, jsonify, send_from_directory
import json, requests, os

app = Flask(__name__, static_folder='.', static_url_path='')

@app.route('/')
def home():
    return send_from_directory('.', 'login.html')

@app.route('/<path:path>')
def static_file(path):
    return send_from_directory('.', path)

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    with open('user.json', 'r', encoding='utf-8') as f:
        users = json.load(f)

    for u in users:
        if u["username"] == username and u["password"] == password:
            return jsonify({"success": True, "role": u["role"]})
    return jsonify({"success": False, "message": "Sai tên đăng nhập hoặc mật khẩu!"})

@app.route('/api/chat', methods=['POST'])
def chat():
    user_message = request.get_json().get("message", "")
    api_url = "https://openrouter.ai/api/v1/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer YOUR_API_KEY_HERE"
    }
    payload = {
        "model": "deepseek/deepseek-chat-v3.1:free",
        "messages": [
            {"role": "system", "content": "You are Eduground Assistant - a helpful school AI bot."},
            {"role": "user", "content": user_message}
        ]
    }
    try:
        res = requests.post(api_url, headers=headers, json=payload, timeout=30)
        if res.status_code == 200:
            data = res.json()
            reply = data["choices"][0]["message"]["content"]
            return jsonify({"response": reply})
        else:
            return jsonify({"error": f"Lỗi phản hồi: {res.status_code}"})
    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
