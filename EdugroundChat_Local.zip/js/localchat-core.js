
const currentUser = sessionStorage.getItem("username");
if (!currentUser) window.location.href = "login.html";

const msgContainer = document.getElementById("messages");
const msgInput = document.getElementById("msgInput");
const sendBtn = document.getElementById("sendBtn");

function loadMessages() {
  const msgs = JSON.parse(localStorage.getItem("messages") || "[]");
  msgContainer.innerHTML = "";
  msgs.forEach(m => addMessage(m.text, m.user === currentUser ? 'sent' : 'received'));
}

function addMessage(text, type) {
  const div = document.createElement("div");
  div.classList.add("message", type);
  div.textContent = text;
  msgContainer.appendChild(div);
  msgContainer.scrollTop = msgContainer.scrollHeight;
}

function sendMessage() {
  const text = msgInput.value.trim();
  if (!text) return;
  const msgs = JSON.parse(localStorage.getItem("messages") || "[]");
  msgs.push({ user: currentUser, text });
  localStorage.setItem("messages", JSON.stringify(msgs));
  addMessage(text, 'sent');
  msgInput.value = "";
}

sendBtn.addEventListener("click", sendMessage);
msgInput.addEventListener("keypress", e => { if (e.key === "Enter") sendMessage(); });
window.onload = loadMessages;
