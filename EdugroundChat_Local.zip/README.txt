
Eduground Chat (Local Edition)
==============================
Phiên bản chat nội bộ lưu bằng LocalStorage.

Tính năng chính:
- Đăng nhập, lưu session, redirect tự động.
- Chat nhóm, chat riêng, gửi ảnh/tệp.
- Lưu tin nhắn offline (localStorage, fallback IndexedDB).
